using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using UiPath.CodedWorkflows;

namespace FIF_005_PFA_StraightThroughProcessing.BusinessLogic
{
    // The XAML caller owns project-standard logging and exception outputs.
    public class OutlookFolderSync : CodedWorkflow
    {
        [Workflow]
        public Dictionary<string, object> Execute(string in_sOutlookAccountName,
            string in_sOutlookITargetFolderName, int in_nStartupTimeoutSeconds,
            int in_nStartupRetryIntervalSeconds, int in_nSyncTimeoutSeconds)
        {
            return OutlookFolderSyncRuntime.Prepare(in_sOutlookAccountName,
                in_sOutlookITargetFolderName, in_nStartupTimeoutSeconds,
                in_nStartupRetryIntervalSeconds, in_nSyncTimeoutSeconds);
        }
    }

    // Uses classic Outlook's current Windows session/profile, not an Outlook service API.
    // A completed Send/Receive cycle is NOT independent proof of server/cache equality.
    public static class OutlookFolderSyncRuntime
    {
        private static readonly object ActiveGate = new object();
        private static WorkerState activeWorker;

        public static Dictionary<string, object> Prepare(string accountName, string folderPath,
            int startupTimeoutSeconds, int retryIntervalSeconds, int syncTimeoutSeconds)
        {
            ValidateArguments(accountName, folderPath, startupTimeoutSeconds,
                retryIntervalSeconds, syncTimeoutSeconds);
            WorkerState state = new WorkerState();
            lock (ActiveGate)
            {
                if (activeWorker != null)
                    throw new InvalidOperationException("Another Outlook synchronization helper is still active in this process. " +
                        "If its caller timed out, COM cleanup is still pending; do not start another synchronization operation.");
                activeWorker = state;
            }

            Thread worker = new Thread(delegate()
            {
                Mutex profileMutex = null;
                bool ownsMutex = false;
                try
                {
                    // AppFolders spans all folders in the profile. Do not lock per mailbox/folder.
                    string sid;
                    int sessionId;
                    using (WindowsIdentity currentIdentity = WindowsIdentity.GetCurrent()) sid = currentIdentity.User.Value;
                    using (Process currentProcess = Process.GetCurrentProcess()) sessionId = currentProcess.SessionId;
                    string mutexName = @"Local\FIF005.OutlookFolderSync." + sid + "." +
                        sessionId.ToString(CultureInfo.InvariantCulture);
                    profileMutex = new Mutex(false, mutexName);
                    Stopwatch lockClock = Stopwatch.StartNew();
                    while (!ownsMutex)
                    {
                        state.Cancellation.Check();
                        int remaining = startupTimeoutSeconds * 1000 - (int)lockClock.ElapsedMilliseconds;
                        if (remaining <= 0)
                            throw new TimeoutException("Timed out waiting for another Outlook synchronization component in this Windows session.");
                        try { ownsMutex = profileMutex.WaitOne(Math.Min(remaining, 100)); }
                        catch (AbandonedMutexException)
                        {
                            ownsMutex = true;
                            state.Diagnostics.Add("Previous helper abandoned the session lock; previous profile cleanup could not be verified.");
                        }
                    }
                    state.Cancellation.Check();
                    CoreOptions options = new CoreOptions(startupTimeoutSeconds * 1000,
                        retryIntervalSeconds * 1000, syncTimeoutSeconds * 1000);
                    state.Result = RunCore(new ComOutlookSession(state.Cancellation), accountName,
                        folderPath, options, state.Cancellation, state.Diagnostics);
                }
                catch (Exception ex) { state.Error = ex; }
                finally
                {
                    // A caller timeout does not release the mutex or COM ownership out from
                    // under the STA. A hung COM call remains quarantined until it returns.
                    try { if (ownsMutex && profileMutex != null) profileMutex.ReleaseMutex(); }
                    catch (Exception ex) { state.Error = Combine(state.Error, ex); }
                    if (profileMutex != null) profileMutex.Dispose();
                    lock (ActiveGate)
                    {
                        if (Object.ReferenceEquals(activeWorker, state)) activeWorker = null;
                    }
                }
            });
            worker.IsBackground = true;
            worker.Name = "Outlook folder readiness and synchronization";
            try
            {
                worker.SetApartmentState(ApartmentState.STA);
                worker.Start();
            }
            catch
            {
                lock (ActiveGate) { if (Object.ReferenceEquals(activeWorker, state)) activeWorker = null; }
                throw;
            }

            // Separate lock + startup budgets, the sync budget and a cleanup allowance.
            // No Thread.Abort, Outlook.Quit, process restart or Outlook process termination.
            int watchdogMs = checked((startupTimeoutSeconds * 2 + syncTimeoutSeconds + 10) * 1000);
            if (!worker.Join(watchdogMs))
            {
                state.Cancellation.Cancel();
                throw new TimeoutException("Outlook preparation exceeded its overall deadline. " +
                    "A COM call or its cleanup may still be blocked. Cleanup is pending on the owned STA worker; " +
                    "subsequent calls in this process are rejected until that worker finishes. " +
                    "Outlook has not been stopped, and folder synchronization membership restoration is not yet confirmed.");
            }
            if (state.Error != null) ExceptionDispatchInfo.Capture(state.Error).Throw();
            return state.Result;
        }

        private static void ValidateArguments(string accountName, string folderPath, int startup, int retry, int sync)
        {
            if (String.IsNullOrWhiteSpace(accountName)) throw new ArgumentException("An explicit Outlook account or mounted mailbox name is required.", "accountName");
            if (String.IsNullOrWhiteSpace(folderPath)) throw new ArgumentException("The complete target folder path is required.", "folderPath");
            GetFolderSegments(folderPath);
            if (startup < 1 || startup > 3600) throw new ArgumentOutOfRangeException("startupTimeoutSeconds", "Use 1 to 3600 seconds.");
            if (retry < 1 || retry > startup) throw new ArgumentOutOfRangeException("retryIntervalSeconds", "Use at least 1 second and no more than the startup timeout.");
            if (sync < 1 || sync > 3600) throw new ArgumentOutOfRangeException("syncTimeoutSeconds", "Use 1 to 3600 seconds.");
        }

        private static string[] GetFolderSegments(string path)
        {
            // Match Get Outlook Mail Messages: paths are relative to the selected mailbox
            // root, split on backslash, with URI decoding applied to each segment.
            string[] segments = path.Split(new char[] { '\\' }, StringSplitOptions.None);
            for (int i = 0; i < segments.Length; i++)
            {
                if (segments[i].Length == 0)
                    throw new ArgumentException("Use a folder path relative to the mailbox root, without leading, trailing or repeated separators (for example Inbox\\PFA_Input).", "folderPath");
                segments[i] = Uri.UnescapeDataString(segments[i]);
            }
            return segments;
        }

        // Internal seam permits synthetic readiness/event/cleanup tests without starting Outlook.
        internal interface IOutlookSyncSession
        {
            void Initialize(string accountName, string folderPath);
            Dictionary<string, object> GetIdentity();
            bool GetMembership();
            void SetMembership(bool value);
            void Subscribe(SyncNotifications notifications);
            void Start();
            void Pump(int milliseconds);
            void BeginCleanup();
            void Stop();
            void Unsubscribe();
            void Release();
        }

        internal sealed class CoreOptions
        {
            internal readonly int StartupMs, RetryMs, SyncMs;
            internal CoreOptions(int startupMs, int retryMs, int syncMs)
            { StartupMs = startupMs; RetryMs = retryMs; SyncMs = syncMs; }
        }

        internal sealed class CancellationState
        {
            private volatile bool cancelled;
            internal void Cancel() { cancelled = true; }
            internal void Check()
            {
                if (cancelled) throw new OperationCanceledException("The Outlook helper caller deadline has elapsed; only cleanup is permitted.");
            }
        }

        internal sealed class SyncNotifications
        {
            internal bool RequestIssued, Started, Ended;
            internal readonly List<string> Errors = new List<string>();
            public void SyncStart() { if (RequestIssued) Started = true; }
            public void SyncEnd() { if (RequestIssued && Started) Ended = true; }
            public void OnError(int code, string description)
            {
                if (RequestIssued) Errors.Add("0x" + unchecked((uint)code).ToString("X8", CultureInfo.InvariantCulture) + ": " + description);
            }
        }

        internal static Dictionary<string, object> RunCore(IOutlookSyncSession session,
            string accountName, string folderPath, CoreOptions options,
            CancellationState cancellation, List<string> diagnostics)
        {
            Dictionary<string, object> result = null;
            Exception failure = null;
            SyncNotifications events = new SyncNotifications();
            bool membershipChanged = false;
            bool originalMembership = false;
            bool startRequested = false;
            Stopwatch startupClock = Stopwatch.StartNew();
            Stopwatch syncClock = new Stopwatch();
            try
            {
                Exception lastStartupError = null;
                int attempt = 0;
                while (true)
                {
                    cancellation.Check();
                    if (attempt > 0 && startupClock.ElapsedMilliseconds >= options.StartupMs)
                        throw new TimeoutException("Outlook or the target folder did not become available within the startup deadline. " +
                            "Account: " + accountName + "; folder: " + folderPath + ".", lastStartupError);
                    attempt++;
                    try
                    {
                        session.Initialize(accountName, folderPath);
                        cancellation.Check();
                        if (startupClock.ElapsedMilliseconds >= options.StartupMs)
                            throw new TimeoutException("Outlook readiness completed after the startup deadline.");
                        diagnostics.Add("Outlook and the exact target folder became accessible on attempt " + attempt + ".");
                        break;
                    }
                    catch (OperationCanceledException) { throw; }
                    catch (ArgumentException) { throw; }
                    catch (Exception ex)
                    {
                        lastStartupError = ex;
                        diagnostics.Add("Readiness attempt " + attempt + ": " + ex.GetType().Name + ": " + ex.Message);
                        int remaining = options.StartupMs - (int)startupClock.ElapsedMilliseconds;
                        if (remaining <= 0)
                            throw new TimeoutException("Outlook or the target folder did not become available within the startup deadline. " +
                                "Account: " + accountName + "; folder: " + folderPath + ".", lastStartupError);
                        session.Pump(Math.Min(options.RetryMs, remaining));
                        cancellation.Check();
                    }
                }
                startupClock.Stop();
                result = session.GetIdentity();
                cancellation.Check();
                syncClock.Start();
                originalMembership = session.GetMembership();
                cancellation.Check();
                if (!originalMembership)
                {
                    // Mark before calling the setter: COM may apply the write and then fail.
                    membershipChanged = true;
                    session.SetMembership(true);
                    cancellation.Check();
                    if (!session.GetMembership())
                        throw new InvalidOperationException("Outlook did not confirm that the target folder belongs to Application Folders.");
                    cancellation.Check();
                }
                session.Subscribe(events);
                cancellation.Check();
                if (syncClock.ElapsedMilliseconds >= options.SyncMs)
                    throw new TimeoutException("The synchronization deadline elapsed while preparing Application Folders.");
                events.RequestIssued = true;
                startRequested = true;
                session.Start();
                cancellation.Check();
                while (true)
                {
                    cancellation.Check();
                    if (events.Errors.Count > 0)
                        throw new InvalidOperationException("Outlook reported synchronization errors: " + String.Join(" | ", events.Errors));
                    if (syncClock.ElapsedMilliseconds >= options.SyncMs)
                        throw new TimeoutException("Outlook did not report a complete, error-free synchronization cycle within the deadline. " +
                            "SyncStart observed: " + events.Started + "; SyncEnd observed: " + events.Ended + ".");
                    if (events.Ended) break;
                    session.Pump(Math.Min(50, Math.Max(1, options.SyncMs - (int)syncClock.ElapsedMilliseconds)));
                    cancellation.Check();
                }
                syncClock.Stop();
                diagnostics.Add("Application Folders reported SyncStart then SyncEnd without OnError; this is not a server/cache equality assertion.");
                result["Ready"] = true;
                result["SyncCycleCompleted"] = true;
                result["StartupElapsedMs"] = startupClock.ElapsedMilliseconds;
                result["SyncElapsedMs"] = syncClock.ElapsedMilliseconds;
            }
            catch (Exception ex) { failure = ex; }
            finally
            {
                // Cleanup remains on the owning STA and is allowed after caller cancellation.
                // If any COM cleanup call hangs, the caller watchdog reports cleanup pending.
                session.BeginCleanup();
                if (startRequested && !events.Ended)
                {
                    try { session.Stop(); }
                    catch (Exception ex) { failure = Combine(failure, new InvalidOperationException("Could not stop the incomplete Application Folders synchronization cycle.", ex)); }
                }
                try { session.Unsubscribe(); }
                catch (Exception ex) { failure = Combine(failure, new InvalidOperationException("Could not detach Outlook synchronization event handlers.", ex)); }
                if (membershipChanged)
                {
                    try { session.SetMembership(originalMembership); }
                    catch (Exception ex) { failure = Combine(failure, new InvalidOperationException("Could not restore the target folder's original synchronization membership.", ex)); }
                }
                try { session.Release(); }
                catch (Exception ex) { failure = Combine(failure, new InvalidOperationException("Could not release helper-owned Outlook COM references.", ex)); }
            }
            if (failure != null) ExceptionDispatchInfo.Capture(failure).Throw();
            diagnostics.Add("Resolved profile: " + result["ProfileName"] + "; store: " + result["StoreName"] +
                "; folder: " + result["FolderPath"] + ".");
            diagnostics.Add("Startup elapsed milliseconds: " + result["StartupElapsedMs"] +
                "; synchronization elapsed milliseconds: " + result["SyncElapsedMs"] + ".");
            result["Diagnostics"] = String.Join(Environment.NewLine, diagnostics);
            return result;
        }

        private static Exception Combine(Exception first, Exception second)
        { return first == null ? second : new AggregateException("Outlook preparation or cleanup failed.", first, second); }

        private sealed class WorkerState
        {
            internal readonly CancellationState Cancellation = new CancellationState();
            internal readonly List<string> Diagnostics = new List<string>();
            internal Dictionary<string, object> Result;
            internal Exception Error;
        }

        private sealed class ComOutlookSession : IOutlookSyncSession
        {
            private readonly CancellationState cancellation;
            private readonly List<object> owned = new List<object>();
            private object app, session, targetFolder, syncObject;
            private Dictionary<string, object> identity;
            private bool cleanup;
            private readonly Guid eventsId = new Guid("00063085-0000-0000-C000-000000000046");
            private Action startHandler, endHandler;
            private Action<int, string> errorHandler;
            private bool startAttached, endAttached, errorAttached;

            internal ComOutlookSession(CancellationState cancellation) { this.cancellation = cancellation; }

            private void Check() { if (!cleanup) cancellation.Check(); }

            private object Own(object value)
            {
                if (value != null && Marshal.IsComObject(value)) owned.Add(value);
                Check();
                return value;
            }

            private object Invoke(object instance, string name, BindingFlags flags, params object[] args)
            {
                Check();
                try
                {
                    object value = instance.GetType().InvokeMember(name, flags, null, instance,
                        args, CultureInfo.InvariantCulture);
                    return Own(value);
                }
                catch (TargetInvocationException ex)
                {
                    Check();
                    if (ex.InnerException != null) ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
                    throw;
                }
            }

            private object Get(object instance, string name, params object[] args)
            { return Invoke(instance, name, BindingFlags.GetProperty, args); }
            private object Call(object instance, string name, params object[] args)
            { return Invoke(instance, name, BindingFlags.InvokeMethod, args); }
            private string Text(object instance, string name)
            { return Convert.ToString(Get(instance, name), CultureInfo.InvariantCulture); }

            public void Initialize(string accountName, string folderPath)
            {
                Check();
                Release();
                Check();
                app = Own(Activator.CreateInstance(Type.GetTypeFromProgID("Outlook.Application", true)));
                session = Call(app, "GetNamespace", "MAPI");
                // Accessing a default folder initializes the default profile without Logon UI.
                Call(session, "GetDefaultFolder", 6);
                if (Convert.ToBoolean(Get(session, "Offline"), CultureInfo.InvariantCulture))
                    throw new InvalidOperationException("Outlook is offline; synchronization readiness is not established.");
                object store = ResolveStore(accountName);
                object root = Call(store, "GetRootFolder");
                string storeName = Text(store, "DisplayName");
                targetFolder = ResolveFolder(root, folderPath);
                if (Convert.ToInt32(Get(targetFolder, "DefaultItemType"), CultureInfo.InvariantCulture) != 0)
                    throw new ArgumentException("The specified Outlook target is not a mail folder.", "folderPath");
                object items = Get(targetFolder, "Items");
                // Zero is valid accessibility; it is never a synchronization-complete signal.
                Get(items, "Count");
                identity = new Dictionary<string, object>(StringComparer.Ordinal)
                {
                    { "ProfileName", Text(session, "CurrentProfileName") },
                    { "FolderPath", Text(targetFolder, "FolderPath") },
                    { "StoreName", storeName },
                    { "FolderEntryId", Text(targetFolder, "EntryID") },
                    { "StoreId", Text(targetFolder, "StoreID") }
                };
                Check();
            }

            private object ResolveStore(string accountName)
            {
                Dictionary<string, object> matches = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                object stores = Get(session, "Stores");
                int count = Convert.ToInt32(Get(stores, "Count"), CultureInfo.InvariantCulture);
                for (int i = 1; i <= count; i++)
                {
                    object store = Get(stores, "Item", i);
                    object root = Call(store, "GetRootFolder");
                    if (EqualsName(Text(store, "DisplayName"), accountName) || EqualsName(Text(root, "Name"), accountName))
                        matches[Text(store, "StoreID")] = store;
                }
                object accounts = Get(session, "Accounts");
                int accountCount = Convert.ToInt32(Get(accounts, "Count"), CultureInfo.InvariantCulture);
                for (int i = 1; i <= accountCount; i++)
                {
                    object account = Get(accounts, "Item", i);
                    if (EqualsName(Text(account, "DisplayName"), accountName) || EqualsName(Text(account, "SmtpAddress"), accountName))
                    {
                        object store = Get(account, "DeliveryStore");
                        if (store != null) matches[Text(store, "StoreID")] = store;
                    }
                }
                // Shared mailboxes need not be Accounts members. Match only their mounted
                // store owner's exact SMTP; never fall back to another mailbox or folder.
                if (matches.Count == 0)
                {
                    for (int i = 1; i <= count; i++)
                    {
                        object store = Get(stores, "Item", i);
                        if (EqualsName(TryGetStoreOwnerSmtp(store), accountName))
                            matches[Text(store, "StoreID")] = store;
                    }
                }
                if (matches.Count == 0)
                    throw new InvalidOperationException("The exact account or mounted shared mailbox is not yet available in Outlook: " + accountName + ".");
                if (matches.Count > 1)
                    throw new ArgumentException("The Outlook account/mailbox name matches more than one store; use an unambiguous name or SMTP address.", "accountName");
                foreach (object match in matches.Values) return match;
                throw new InvalidOperationException("No Outlook mailbox store was resolved.");
            }

            private string TryGetStoreOwnerSmtp(object store)
            {
                try
                {
                    object accessor = Get(store, "PropertyAccessor");
                    object binaryId = Call(accessor, "GetProperty", "http://schemas.microsoft.com/mapi/proptag/0x661B0102");
                    string entryId = Convert.ToString(Call(accessor, "BinaryToString", binaryId), CultureInfo.InvariantCulture);
                    object addressEntry = Call(session, "GetAddressEntryFromID", entryId);
                    int type = Convert.ToInt32(Get(addressEntry, "AddressEntryUserType"), CultureInfo.InvariantCulture);
                    object exchangeEntry = null;
                    if (type == 0 || type == 5) exchangeEntry = Call(addressEntry, "GetExchangeUser");
                    else if (type == 1) exchangeEntry = Call(addressEntry, "GetExchangeDistributionList");
                    return exchangeEntry == null ? null : Text(exchangeEntry, "PrimarySmtpAddress");
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception) { Check(); return null; } // Non-Exchange stores may not expose an owner.
            }

            private object ResolveFolder(object root, string path)
            {
                string[] segments = GetFolderSegments(path);
                object folder = root;
                for (int i = 0; i < segments.Length; i++)
                {
                    object children = Get(folder, "Folders");
                    int count = Convert.ToInt32(Get(children, "Count"), CultureInfo.InvariantCulture);
                    object match = null;
                    for (int j = 1; j <= count; j++)
                    {
                        object child = Get(children, "Item", j);
                        if (EqualsName(Text(child, "Name"), segments[i]))
                        {
                            if (match != null) throw new ArgumentException("Ambiguous Outlook folder segment: " + segments[i] + ".", "folderPath");
                            match = child;
                        }
                    }
                    if (match == null) throw new InvalidOperationException("The exact Outlook folder is not yet available. Missing segment: " + segments[i] + "; requested path: " + path + ".");
                    folder = match;
                }
                return folder;
            }

            private static bool EqualsName(string left, string right)
            { return String.Equals(left, right, StringComparison.InvariantCultureIgnoreCase); }

            public Dictionary<string, object> GetIdentity()
            { Check(); return new Dictionary<string, object>(identity, StringComparer.Ordinal); }
            public bool GetMembership()
            { return Convert.ToBoolean(Get(targetFolder, "InAppFolderSyncObject"), CultureInfo.InvariantCulture); }
            public void SetMembership(bool value)
            { Invoke(targetFolder, "InAppFolderSyncObject", BindingFlags.SetProperty, value); }
            public void Subscribe(SyncNotifications notifications)
            {
                object syncObjects = Get(session, "SyncObjects");
                syncObject = Get(syncObjects, "AppFolders");
                startHandler = notifications.SyncStart;
                errorHandler = notifications.OnError;
                endHandler = notifications.SyncEnd;
                Check();
                // Mark first so partial COM subscription failures are still cleaned up.
                startAttached = true;
                ComEventsHelper.Combine(syncObject, eventsId, 61441, startHandler);
                Check();
                errorAttached = true;
                ComEventsHelper.Combine(syncObject, eventsId, 61443, errorHandler);
                Check();
                endAttached = true;
                ComEventsHelper.Combine(syncObject, eventsId, 61444, endHandler);
                Check();
            }
            public void Start() { Call(syncObject, "Start"); }
            public void Stop() { if (syncObject != null) Call(syncObject, "Stop"); }
            public void BeginCleanup() { cleanup = true; }

            public void Unsubscribe()
            {
                Exception failure = null;
                if (startAttached)
                {
                    try { ComEventsHelper.Remove(syncObject, eventsId, 61441, startHandler); startAttached = false; }
                    catch (Exception ex) { failure = Combine(failure, ex); }
                }
                if (errorAttached)
                {
                    try { ComEventsHelper.Remove(syncObject, eventsId, 61443, errorHandler); errorAttached = false; }
                    catch (Exception ex) { failure = Combine(failure, ex); }
                }
                if (endAttached)
                {
                    try { ComEventsHelper.Remove(syncObject, eventsId, 61444, endHandler); endAttached = false; }
                    catch (Exception ex) { failure = Combine(failure, ex); }
                }
                if (failure != null) ExceptionDispatchInfo.Capture(failure).Throw();
            }

            public void Release()
            {
                Exception failure = null;
                // One Release per acquired reference; never invalidate another caller's RCW
                // with FinalReleaseComObject, and never close the shared Outlook application.
                for (int i = owned.Count - 1; i >= 0; i--)
                {
                    try { if (Marshal.IsComObject(owned[i])) Marshal.ReleaseComObject(owned[i]); }
                    catch (Exception ex) { failure = Combine(failure, ex); }
                }
                owned.Clear();
                app = session = targetFolder = syncObject = null;
                identity = null;
                if (failure != null) ExceptionDispatchInfo.Capture(failure).Throw();
            }

            public void Pump(int milliseconds)
            {
                Stopwatch clock = Stopwatch.StartNew();
                do
                {
                    Check();
                    NativeMessage message;
                    while (PeekMessage(out message, IntPtr.Zero, 0, 0, 1))
                    {
                        Check();
                        if (message.Message == 0x0012)
                            throw new OperationCanceledException("The Outlook helper STA received WM_QUIT.");
                        TranslateMessage(ref message);
                        DispatchMessage(ref message);
                        Check();
                        if (clock.ElapsedMilliseconds >= milliseconds) break;
                    }
                    int remaining = milliseconds - (int)clock.ElapsedMilliseconds;
                    if (remaining <= 0) break;
                    uint waitResult = MsgWaitForMultipleObjectsEx(0, IntPtr.Zero,
                        (uint)Math.Min(remaining, 50), 0x04FF, 0x0004);
                    Check();
                    if (waitResult == 0xFFFFFFFF)
                        throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), "The Outlook STA message wait failed.");
                } while (clock.ElapsedMilliseconds < milliseconds);
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint { internal int X, Y; }
        [StructLayout(LayoutKind.Sequential)]
        private struct NativeMessage
        {
            internal IntPtr Window;
            internal uint Message;
            internal UIntPtr WParam;
            internal IntPtr LParam;
            internal uint Time;
            internal NativePoint Point;
            internal uint Private;
        }
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool PeekMessage(out NativeMessage message, IntPtr window, uint minimum, uint maximum, uint remove);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool TranslateMessage(ref NativeMessage message);
        [DllImport("user32.dll")]
        private static extern IntPtr DispatchMessage(ref NativeMessage message);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint MsgWaitForMultipleObjectsEx(uint count, IntPtr handles, uint milliseconds, uint wakeMask, uint flags);
    }
}
